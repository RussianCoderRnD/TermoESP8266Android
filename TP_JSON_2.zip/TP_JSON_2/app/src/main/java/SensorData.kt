
    data class SensorData(
//    список переменных
        val LG: Float,
        val PG: Float,
        val LP: Float,
        val PP: Float,
        val STOP: Float,
        val ZX: Float,
        val FOG: Float,
        val BATT: Int
    )

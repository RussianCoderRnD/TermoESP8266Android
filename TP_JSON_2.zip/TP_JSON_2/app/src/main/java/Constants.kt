import android.util.Half.toFloat

object Constants {
    val namesLines = listOf("Левый габарит", "Правый габарит", "Левый поворот", "Правый поворот", "STOP", "Задний ход", "Противотуманка")
    val SumbolA = listOf("A", "A", "A", "A", "A", "A", "A")

    var KZ = 8.0.toFloat()
    var OBR = 0.15.toFloat()
    var rrr=0.0.toFloat()

    var LG_PG_OK = 1.0.toFloat()
    var LG_PG_Koff = 0.40.toFloat()
    var LG_PG_Dw = 0.30.toFloat()

    var LP_PP_OK = 2.0.toFloat()
    var LP_PP_Up = 0.30.toFloat()
    var LP_PP_Dw = 0.30.toFloat()

    var STOP_OK = 4.00.toFloat()
    var STOP_Up = 0.30.toFloat()
    var STOP_Dw = 0.30.toFloat()

    var ZX_OK = 2.00.toFloat()
    var ZX_Up = 0.30.toFloat()
    var ZX_Dw = 0.30.toFloat()

    var FOG_OK = 2.0.toFloat()
    var FOG_Up = 0.30.toFloat()
    var FOG_Dw = 0.30.toFloat()

    val LG1 = 0
    val PG1 = 0

}
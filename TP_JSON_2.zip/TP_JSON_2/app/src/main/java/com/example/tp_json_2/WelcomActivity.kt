package com.example.tp_json_2

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.graphics.Color
import android.content.pm.ActivityInfo

class WelcomActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Устанавливаем ориентацию на портретную необходимо импортировать --- import android.content.pm.ActivityInfo
                requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT

        enableEdgeToEdge()
        setContentView(R.layout.activity_welcom)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        val startButton: Button = findViewById(R.id.startButton)
        startButton.setOnClickListener {
            // При нажатии на кнопку запускаем MainActivity
            startActivity(Intent(this, MainActivity::class.java))
            finish() // Закрываем SplashActivity
        }
        // Установить белый цвет фона
       startButton.setBackgroundColor(Color.WHITE)
    }

}